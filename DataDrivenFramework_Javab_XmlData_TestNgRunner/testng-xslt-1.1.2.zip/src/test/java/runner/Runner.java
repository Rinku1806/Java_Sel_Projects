package runner;

import java.util.ArrayList;
import java.util.List;

public class Runner {

	public static void main(String[] args) {
		TestNGRunner testNG = new TestNGRunner(1);
		testNG.createSuite("JPetStore", false);
		testNG.addListener("listener.MyTestNGListener");// later	
		List<String> includedMethods = new ArrayList<String>();
		testNG.addTestClass("testcases.DashBoardTest", includedMethods);
		includedMethods = new ArrayList<String>();
		includedMethods.add("verifyAvailablePets");
		includedMethods.add("verifyAllPets");	
		testNG.addTestClass("testcases.HomePageTest", includedMethods);
		includedMethods = new ArrayList<String>();
		includedMethods.add("VerifyHomePageTitle");		
		testNG.addTestClass("testcases.StoreEntryTest", includedMethods);
		includedMethods = new ArrayList<String>();
		includedMethods.add("VerifySignInButtonPresence");
		includedMethods.add("VerifyStoreEntryTitle");
		includedMethods.add("Verifylogin");	
		testNG.run();	
		
	}
}
